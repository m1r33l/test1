import{j as t,O as s}from"./index-CKf8WwuA.js";import"./pagination-BlIMZx3U.js";function m(){return t.jsx("div",{className:"md:mt-16 mt-24 pb-10",children:t.jsx(s,{})})}export{m as default};
